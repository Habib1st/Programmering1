﻿
namespace PokerLite
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pcbÖppet = new System.Windows.Forms.PictureBox();
            this.pcbSpelare2Kort2 = new System.Windows.Forms.PictureBox();
            this.pcbSpelare2Kort3 = new System.Windows.Forms.PictureBox();
            this.pcbSpelare2Kort4 = new System.Windows.Forms.PictureBox();
            this.pcbSpelare2Kort5 = new System.Windows.Forms.PictureBox();
            this.pcbSpelare2Kort1 = new System.Windows.Forms.PictureBox();
            this.pcbSpelare1Kort2 = new System.Windows.Forms.PictureBox();
            this.pcbSpelare1Kort3 = new System.Windows.Forms.PictureBox();
            this.pcbSpelare1Kort4 = new System.Windows.Forms.PictureBox();
            this.pcbSpelare1Kort5 = new System.Windows.Forms.PictureBox();
            this.pcbSpelare1Kort1 = new System.Windows.Forms.PictureBox();
            this.pcbKortlek = new System.Windows.Forms.PictureBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnKlar = new System.Windows.Forms.Button();
            this.gbxSpelare1 = new System.Windows.Forms.GroupBox();
            this.gbxSpelare2 = new System.Windows.Forms.GroupBox();
            this.pcbSläng = new System.Windows.Forms.PictureBox();
            this.lblPoängSp1 = new System.Windows.Forms.Label();
            this.lblPoängSp2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pcbÖppet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare2Kort2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare2Kort3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare2Kort4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare2Kort5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare2Kort1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare1Kort2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare1Kort3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare1Kort4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare1Kort5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare1Kort1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbKortlek)).BeginInit();
            this.gbxSpelare1.SuspendLayout();
            this.gbxSpelare2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSläng)).BeginInit();
            this.SuspendLayout();
            // 
            // pcbÖppet
            // 
            this.pcbÖppet.Location = new System.Drawing.Point(12, 173);
            this.pcbÖppet.Name = "pcbÖppet";
            this.pcbÖppet.Size = new System.Drawing.Size(71, 96);
            this.pcbÖppet.TabIndex = 23;
            this.pcbÖppet.TabStop = false;
            this.pcbÖppet.Click += new System.EventHandler(this.pcbÖppet_Click);
            // 
            // pcbSpelare2Kort2
            // 
            this.pcbSpelare2Kort2.Location = new System.Drawing.Point(84, 19);
            this.pcbSpelare2Kort2.Name = "pcbSpelare2Kort2";
            this.pcbSpelare2Kort2.Size = new System.Drawing.Size(71, 96);
            this.pcbSpelare2Kort2.TabIndex = 22;
            this.pcbSpelare2Kort2.TabStop = false;
            this.pcbSpelare2Kort2.Click += new System.EventHandler(this.pcbSpelare2Kort2_Click);
            // 
            // pcbSpelare2Kort3
            // 
            this.pcbSpelare2Kort3.Location = new System.Drawing.Point(161, 19);
            this.pcbSpelare2Kort3.Name = "pcbSpelare2Kort3";
            this.pcbSpelare2Kort3.Size = new System.Drawing.Size(71, 96);
            this.pcbSpelare2Kort3.TabIndex = 21;
            this.pcbSpelare2Kort3.TabStop = false;
            this.pcbSpelare2Kort3.Click += new System.EventHandler(this.pcbSpelare2Kort3_Click);
            // 
            // pcbSpelare2Kort4
            // 
            this.pcbSpelare2Kort4.Location = new System.Drawing.Point(238, 19);
            this.pcbSpelare2Kort4.Name = "pcbSpelare2Kort4";
            this.pcbSpelare2Kort4.Size = new System.Drawing.Size(71, 96);
            this.pcbSpelare2Kort4.TabIndex = 20;
            this.pcbSpelare2Kort4.TabStop = false;
            this.pcbSpelare2Kort4.Click += new System.EventHandler(this.pcbSpelare2Kort4_Click);
            // 
            // pcbSpelare2Kort5
            // 
            this.pcbSpelare2Kort5.Location = new System.Drawing.Point(315, 19);
            this.pcbSpelare2Kort5.Name = "pcbSpelare2Kort5";
            this.pcbSpelare2Kort5.Size = new System.Drawing.Size(71, 96);
            this.pcbSpelare2Kort5.TabIndex = 19;
            this.pcbSpelare2Kort5.TabStop = false;
            this.pcbSpelare2Kort5.Click += new System.EventHandler(this.pcbSpelare2Kort5_Click);
            // 
            // pcbSpelare2Kort1
            // 
            this.pcbSpelare2Kort1.Location = new System.Drawing.Point(7, 19);
            this.pcbSpelare2Kort1.Name = "pcbSpelare2Kort1";
            this.pcbSpelare2Kort1.Size = new System.Drawing.Size(71, 96);
            this.pcbSpelare2Kort1.TabIndex = 18;
            this.pcbSpelare2Kort1.TabStop = false;
            this.pcbSpelare2Kort1.Click += new System.EventHandler(this.pcbSpelare2Kort1_Click);
            // 
            // pcbSpelare1Kort2
            // 
            this.pcbSpelare1Kort2.Location = new System.Drawing.Point(83, 20);
            this.pcbSpelare1Kort2.Name = "pcbSpelare1Kort2";
            this.pcbSpelare1Kort2.Size = new System.Drawing.Size(71, 96);
            this.pcbSpelare1Kort2.TabIndex = 17;
            this.pcbSpelare1Kort2.TabStop = false;
            this.pcbSpelare1Kort2.Click += new System.EventHandler(this.pcbSpelare1Kort2_Click);
            // 
            // pcbSpelare1Kort3
            // 
            this.pcbSpelare1Kort3.Location = new System.Drawing.Point(160, 20);
            this.pcbSpelare1Kort3.Name = "pcbSpelare1Kort3";
            this.pcbSpelare1Kort3.Size = new System.Drawing.Size(71, 96);
            this.pcbSpelare1Kort3.TabIndex = 16;
            this.pcbSpelare1Kort3.TabStop = false;
            this.pcbSpelare1Kort3.Click += new System.EventHandler(this.pcbSpelare1Kort3_Click);
            // 
            // pcbSpelare1Kort4
            // 
            this.pcbSpelare1Kort4.Location = new System.Drawing.Point(237, 20);
            this.pcbSpelare1Kort4.Name = "pcbSpelare1Kort4";
            this.pcbSpelare1Kort4.Size = new System.Drawing.Size(71, 96);
            this.pcbSpelare1Kort4.TabIndex = 15;
            this.pcbSpelare1Kort4.TabStop = false;
            this.pcbSpelare1Kort4.Click += new System.EventHandler(this.pcbSpelare1Kort4_Click);
            // 
            // pcbSpelare1Kort5
            // 
            this.pcbSpelare1Kort5.Location = new System.Drawing.Point(314, 20);
            this.pcbSpelare1Kort5.Name = "pcbSpelare1Kort5";
            this.pcbSpelare1Kort5.Size = new System.Drawing.Size(71, 96);
            this.pcbSpelare1Kort5.TabIndex = 14;
            this.pcbSpelare1Kort5.TabStop = false;
            this.pcbSpelare1Kort5.Click += new System.EventHandler(this.pcbSpelare1Kort5_Click);
            // 
            // pcbSpelare1Kort1
            // 
            this.pcbSpelare1Kort1.Location = new System.Drawing.Point(6, 20);
            this.pcbSpelare1Kort1.Name = "pcbSpelare1Kort1";
            this.pcbSpelare1Kort1.Size = new System.Drawing.Size(71, 96);
            this.pcbSpelare1Kort1.TabIndex = 13;
            this.pcbSpelare1Kort1.TabStop = false;
            this.pcbSpelare1Kort1.Click += new System.EventHandler(this.pcbSpelare1Kort1_Click);
            // 
            // pcbKortlek
            // 
            this.pcbKortlek.Enabled = false;
            this.pcbKortlek.Image = global::PokerLite.KortGrafik.back;
            this.pcbKortlek.Location = new System.Drawing.Point(12, 42);
            this.pcbKortlek.Name = "pcbKortlek";
            this.pcbKortlek.Size = new System.Drawing.Size(71, 96);
            this.pcbKortlek.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pcbKortlek.TabIndex = 12;
            this.pcbKortlek.TabStop = false;
            this.pcbKortlek.Click += new System.EventHandler(this.pcbKortlek_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(103, 144);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(71, 23);
            this.btnStart.TabIndex = 24;
            this.btnStart.Text = "Starta";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnKlar
            // 
            this.btnKlar.Enabled = false;
            this.btnKlar.Location = new System.Drawing.Point(257, 144);
            this.btnKlar.Name = "btnKlar";
            this.btnKlar.Size = new System.Drawing.Size(71, 23);
            this.btnKlar.TabIndex = 25;
            this.btnKlar.Text = "Klar";
            this.btnKlar.UseVisualStyleBackColor = true;
            this.btnKlar.Click += new System.EventHandler(this.btnKlar_Click);
            // 
            // gbxSpelare1
            // 
            this.gbxSpelare1.Controls.Add(this.pcbSpelare1Kort1);
            this.gbxSpelare1.Controls.Add(this.pcbSpelare1Kort5);
            this.gbxSpelare1.Controls.Add(this.pcbSpelare1Kort4);
            this.gbxSpelare1.Controls.Add(this.pcbSpelare1Kort3);
            this.gbxSpelare1.Controls.Add(this.pcbSpelare1Kort2);
            this.gbxSpelare1.Enabled = false;
            this.gbxSpelare1.Location = new System.Drawing.Point(103, 12);
            this.gbxSpelare1.Name = "gbxSpelare1";
            this.gbxSpelare1.Size = new System.Drawing.Size(392, 126);
            this.gbxSpelare1.TabIndex = 26;
            this.gbxSpelare1.TabStop = false;
            this.gbxSpelare1.Text = "Spelare 1";
            // 
            // gbxSpelare2
            // 
            this.gbxSpelare2.Controls.Add(this.pcbSpelare2Kort5);
            this.gbxSpelare2.Controls.Add(this.pcbSpelare2Kort1);
            this.gbxSpelare2.Controls.Add(this.pcbSpelare2Kort4);
            this.gbxSpelare2.Controls.Add(this.pcbSpelare2Kort3);
            this.gbxSpelare2.Controls.Add(this.pcbSpelare2Kort2);
            this.gbxSpelare2.Enabled = false;
            this.gbxSpelare2.Location = new System.Drawing.Point(103, 173);
            this.gbxSpelare2.Name = "gbxSpelare2";
            this.gbxSpelare2.Size = new System.Drawing.Size(392, 126);
            this.gbxSpelare2.TabIndex = 27;
            this.gbxSpelare2.TabStop = false;
            this.gbxSpelare2.Text = "Spelare 2";
            // 
            // pcbSläng
            // 
            this.pcbSläng.Location = new System.Drawing.Point(514, 102);
            this.pcbSläng.Name = "pcbSläng";
            this.pcbSläng.Size = new System.Drawing.Size(71, 96);
            this.pcbSläng.TabIndex = 28;
            this.pcbSläng.TabStop = false;
            // 
            // lblPoängSp1
            // 
            this.lblPoängSp1.AutoSize = true;
            this.lblPoängSp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPoängSp1.Location = new System.Drawing.Point(536, 42);
            this.lblPoängSp1.Name = "lblPoängSp1";
            this.lblPoängSp1.Size = new System.Drawing.Size(24, 26);
            this.lblPoängSp1.TabIndex = 29;
            this.lblPoängSp1.Text = "0";
            // 
            // lblPoängSp2
            // 
            this.lblPoängSp2.AutoSize = true;
            this.lblPoängSp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPoängSp2.Location = new System.Drawing.Point(536, 243);
            this.lblPoängSp2.Name = "lblPoängSp2";
            this.lblPoängSp2.Size = new System.Drawing.Size(24, 26);
            this.lblPoängSp2.TabIndex = 30;
            this.lblPoängSp2.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(597, 305);
            this.Controls.Add(this.lblPoängSp2);
            this.Controls.Add(this.lblPoängSp1);
            this.Controls.Add(this.pcbSläng);
            this.Controls.Add(this.gbxSpelare2);
            this.Controls.Add(this.gbxSpelare1);
            this.Controls.Add(this.btnKlar);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.pcbÖppet);
            this.Controls.Add(this.pcbKortlek);
            this.Name = "Form1";
            this.Text = "Poker Lite";
            ((System.ComponentModel.ISupportInitialize)(this.pcbÖppet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare2Kort2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare2Kort3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare2Kort4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare2Kort5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare2Kort1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare1Kort2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare1Kort3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare1Kort4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare1Kort5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSpelare1Kort1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbKortlek)).EndInit();
            this.gbxSpelare1.ResumeLayout(false);
            this.gbxSpelare2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcbSläng)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pcbÖppet;
        private System.Windows.Forms.PictureBox pcbSpelare2Kort2;
        private System.Windows.Forms.PictureBox pcbSpelare2Kort3;
        private System.Windows.Forms.PictureBox pcbSpelare2Kort4;
        private System.Windows.Forms.PictureBox pcbSpelare2Kort5;
        private System.Windows.Forms.PictureBox pcbSpelare2Kort1;
        private System.Windows.Forms.PictureBox pcbSpelare1Kort2;
        private System.Windows.Forms.PictureBox pcbSpelare1Kort3;
        private System.Windows.Forms.PictureBox pcbSpelare1Kort4;
        private System.Windows.Forms.PictureBox pcbSpelare1Kort5;
        private System.Windows.Forms.PictureBox pcbSpelare1Kort1;
        private System.Windows.Forms.PictureBox pcbKortlek;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnKlar;
        private System.Windows.Forms.GroupBox gbxSpelare1;
        private System.Windows.Forms.GroupBox gbxSpelare2;
        private System.Windows.Forms.PictureBox pcbSläng;
        private System.Windows.Forms.Label lblPoängSp1;
        private System.Windows.Forms.Label lblPoängSp2;
    }
}

